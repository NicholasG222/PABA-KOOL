package com.example.kool

data class RatingData(
    var review: String,
    var rating: Int,
    var email: String,
    var namaKost: String
)
